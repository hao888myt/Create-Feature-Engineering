# **Explorer's Compass结构汉化补充**

![pack](https://github.com/user-attachments/assets/4cb8902e-5402-4758-9a59-ee2afd85ccda)

## 介绍

本项目在于探险家指南针的结构汉化

有想要的结构汉化可以提issue，也欢迎大家来提交新的结构的补充汉化

> 已汉化Mod详见更新日志

本项目下载位置：https://github.com/CLOT-LIU/explorerscompass-CHS/releases

国内下载地址：https://bbsmc.net/resourcepack/explorerscompass-chs