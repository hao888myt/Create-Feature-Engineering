本包由Haiyanbaka制作
用于汉化tetra1.20.1-6.5.0版本。更早的版本不知道能不能用
github仓库地址https://github.com/Haiyan451/zh_cn_4_tetra_mod/